package com.immomo.momo.android.activity.maintabs;

import com.immomo.momo.android.BaseActivity;

public abstract class TabItemActivity extends BaseActivity {
	protected abstract void init();
}
