package com.immomo.momo.android.activity.maintabs;

import android.os.Bundle;

import com.immomo.momo.android.R;

public class ContactTabsActivity extends TabItemActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_contacttabs);
		System.out.println("ContactTabsActivity");
	}
	@Override
	protected void initViews() {
		
	}

	@Override
	protected void initEvents() {
		
	}
	@Override
	protected void init() {
		
	}

}
