package com.immomo.momo.android.activity.message;

import android.content.Context;

import com.immomo.momo.android.entity.Message;

public class VoiceMessageItem extends MessageItem {

	public VoiceMessageItem(Message msg, Context context) {
		super(msg, context);
	}

	@Override
	protected void onInitViews() {

	}

	@Override
	protected void onFillMessage() {

	}

}
