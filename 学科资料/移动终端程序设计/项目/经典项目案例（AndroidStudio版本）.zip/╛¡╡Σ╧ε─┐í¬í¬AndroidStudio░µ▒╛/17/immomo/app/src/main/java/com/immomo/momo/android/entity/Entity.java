package com.immomo.momo.android.entity;

/**
 * @fileName Entity.java
 * @package com.immomo.momo.android.entity
 * @description 实体基类
 * @author 任东卫
 * @email 86930007@qq.com
 * @version 1.0
 */
public class Entity {
	// 本来想做些什么来,暂时空着吧
}
