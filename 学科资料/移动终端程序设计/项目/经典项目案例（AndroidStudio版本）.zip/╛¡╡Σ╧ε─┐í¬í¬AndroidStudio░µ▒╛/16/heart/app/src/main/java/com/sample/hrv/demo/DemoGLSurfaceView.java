package com.sample.hrv.demo;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.util.AttributeSet;

/**
 * Created by steven on 9/5/13.
 * Modified by olli on 3/28/2014.
 */
public class DemoGLSurfaceView extends GLSurfaceView {

    public DemoGLSurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
