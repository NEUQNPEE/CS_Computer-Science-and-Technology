package com.kircherelectronics.gyroscopeexplorer.activity.prefs;

public class HintsPreferences
{
	public final static String FIRST_RUN_HINTS_ENABLED = "first_run_hints_enabled";
}
