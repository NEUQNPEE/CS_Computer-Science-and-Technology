package com.gesture;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class MyView extends SurfaceView implements SurfaceHolder.Callback {
	SurfaceHolder holder;
	static float x;
	static float y;
	public MyView(Context context) {
		super(context);
		holder = this.getHolder();//��ȡholder
    	holder.addCallback(this);
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		new Thread(new MyThread()).start();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		
	}
	public class MyThread implements Runnable {
		Paint paint=new Paint();
		@Override
		public void run() {
			// TODO Auto-generated method stub
			while(true){
				Canvas canvas = holder.lockCanvas(null);//��ȡ����
				paint.setColor(Color.BLACK);
//				canvas.drawRect(0, 0, 320, 480, paint);����
				canvas.drawRect(0, 0, 480, 320, paint);
				paint.setColor(Color.GREEN);
				canvas.drawRect(x-5, y-5, x+5, y+5, paint);
				
				holder.unlockCanvasAndPost(canvas);// �����������ύ���õ�ͼ��
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
