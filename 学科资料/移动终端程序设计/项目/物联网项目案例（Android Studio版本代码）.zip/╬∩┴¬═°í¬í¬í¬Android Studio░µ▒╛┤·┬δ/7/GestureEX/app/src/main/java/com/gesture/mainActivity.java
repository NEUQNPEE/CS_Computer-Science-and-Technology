package com.gesture;

import android.app.Activity;import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.Window;
import android.view.WindowManager;

public class mainActivity extends Activity{
	private GestureDetector mGestureDetector;;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mGestureDetector = new GestureDetector(this, new MyGestureListener()); 
        
        if(getRequestedOrientation()!=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE){
        	setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }
        
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //��ȥ��ص�ͼ���һ�����β��֣�״̬�����֣�
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // ��ȥ����������������֣�
        setContentView(new MyView(this));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) { 
       if (mGestureDetector.onTouchEvent(event)) 
            return true; 
       else
            return false; 
    } 
}