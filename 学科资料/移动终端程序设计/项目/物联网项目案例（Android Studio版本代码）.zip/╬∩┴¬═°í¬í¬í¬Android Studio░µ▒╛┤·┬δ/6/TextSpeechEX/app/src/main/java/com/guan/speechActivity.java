package com.guan;

import java.util.Locale;
import com.google.tts.TTS;
import com.terry.R;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class speechActivity extends Activity  implements TextToSpeech.OnInitListener{
	private TextToSpeech mSpeech;
	private Button btn;
	static final int TTS_CHECK_CODE = 0;
	private EditText mEditText;
	private TTS myTts;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		btn = (Button) findViewById(R.id.Button01);
		mEditText = (EditText) findViewById(R.id.EditText01);
		//btn.setEnabled(false);
		myTts = new TTS(this, ttsInitListener, true);
		mSpeech = new TextToSpeech(this, this);
		btn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				myTts.setLanguage("CHINESE");
		          myTts.speak(mEditText.getText().toString(), 0, null);
				mSpeech.speak(mEditText.getText().toString(),
						TextToSpeech.QUEUE_FLUSH, null);
			}
		});
	}
	
	private TTS.InitListener ttsInitListener = new TTS.InitListener() {
	        public void onInit(int version) {
	          myTts.setLanguage("CHINESE");
	          myTts.speak("�ְ�", 0, null);
	        }
	};

	
	public void onInit(int status) {
		if (status == TextToSpeech.SUCCESS) {
			int result = mSpeech.setLanguage(Locale.CHINA);
			if (result == TextToSpeech.LANG_MISSING_DATA
					|| result == TextToSpeech.LANG_NOT_SUPPORTED) {
				Log.e("lanageTag", "not use");
			} else {
				btn.setEnabled(true);
				mSpeech.speak("��ϲ����", TextToSpeech.QUEUE_FLUSH,
						null);
			}
		}
	}

	@Override
	protected void onDestroy() {
		if (mSpeech != null) {
			mSpeech.stop();
			mSpeech.shutdown();
		}
		super.onDestroy();
	}
}