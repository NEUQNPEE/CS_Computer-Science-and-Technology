package com.example.qiang;
import org.openintents.sensorsimulator.hardware.Sensor;  
import android.app.Activity;  
import android.hardware.SensorManager;  
import android.os.Bundle;  
import android.widget.TextView;  
  
public  class MainActivity extends Activity implements  android.hardware.SensorEventListener {  
      
    private TextView myTextView1;  
  
    private SensorManager mySensorManager;  
  
    @Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
        setContentView(R.layout.main);  
        myTextView1 = (TextView) findViewById(R.id.myTextView1);  
        mySensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);  
  
    }  
  
    @Override  
    protected void onResume() {  
        mySensorManager.registerListener(  
                this,  
                mySensorManager.getDefaultSensor(Sensor.TYPE_LIGHT),  
                SensorManager.SENSOR_DELAY_GAME  
                );  
        super.onResume();  
    }  
  
    @Override  
    protected void onStop() {  
        // TODO Auto-generated method stub  
        mySensorManager.unregisterListener(this);  
        super.onStop();  
    }  
    @Override  
    protected void onPause() {  
        mySensorManager.unregisterListener(this);  
        super.onPause();  
    }  
  
    @Override  
    public void onAccuracyChanged(android.hardware.Sensor sensor, int accuracy) {  
        // TODO Auto-generated method stub  
          
    }  
  
    @Override  
    public void onSensorChanged(android.hardware.SensorEvent event) {  
        // TODO Auto-generated method stub  
        float[] values = event.values;  
        int sensorType = event.sensor.TYPE_LIGHT;  
        if (sensorType == Sensor.TYPE_LIGHT) {  
            myTextView1.setText("��ǰ���ǿ��Ϊ��"+values[0]);        
        }  
    }  
  
}  