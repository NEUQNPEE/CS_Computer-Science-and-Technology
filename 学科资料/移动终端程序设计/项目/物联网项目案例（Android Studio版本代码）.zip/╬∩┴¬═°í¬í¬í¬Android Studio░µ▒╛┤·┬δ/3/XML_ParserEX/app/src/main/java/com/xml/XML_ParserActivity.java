package com.xml;

import com.mmm.xml.R;

import android.app.Activity;
import android.os.Bundle;

public class XML_ParserActivity extends Activity {
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}