package com.kircherelectronics.gyroscopeexplorer.activity.prefs;

/**
 * Static class for the SharedPreferences strings.
 * 
 * @author Kaleb
 * @version %I%, %G%
 */
public class PreferenceNames
{
	public final static String HINTS = "hints_preferences";
}
