package org.lock;

import com.autolock.R;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private Button start;
	private Button stop;
	private Button exit;
	private TextView sensorinfo_tv;
	private Intent intent;
	private SensorManager sm = null;
	private Sensor promixty = null;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		if (null == sm) {
			sm = (SensorManager) getSystemService(SENSOR_SERVICE); // ��ȡ������������
			promixty = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY); // ��ȡ���봫����
		}
		String sensorInfo;
		if (null != promixty) {
			sensorInfo = "���������ƣ�" + promixty.getName() + "\n"
					+ "  �豸�汾��" + promixty.getVersion() + "\n" + "  ��Ӧ�̣�"
					+ promixty.getVendor() + "\n";
		}
		else {
			sensorInfo = "�޷���ȡ���봫������Ϣ�������������ֻ���֧�ָô�������";
		}
		initUI();
		intent = new Intent("org.hq.autoLockService");
		start.setOnClickListener( new OnClickListener() {
			@Override
			public void onClick(View v) {
				//��������
				start();
			}
		});
		stop.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// ֹͣ����
				stop();
			}
		});
		exit.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// ��������Activity
				finish();
			}
		});
		sensorinfo_tv.setText(sensorInfo);
	}

	private void initUI(){
		start = (Button) super.findViewById(R.id.start);
		stop = (Button) super.findViewById(R.id.stop);
		exit = (Button) super.findViewById(R.id.exit);
		sensorinfo_tv = (TextView) super.findViewById(R.id.sensorinfo_tv);
	}
	
	private void start(){
		Bundle bundle = new Bundle();
		bundle.putInt("distance", 3);
		bundle.putBoolean("activited", true);
		intent.putExtras(bundle);
		startService(intent);							// startService
		//��������Activity
		//finish();
	}
	//��ֹ����
	private void stop(){
		stopService(intent);
		Toast.makeText(this, "��ֹͣ��̨����", Toast.LENGTH_SHORT).show();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
