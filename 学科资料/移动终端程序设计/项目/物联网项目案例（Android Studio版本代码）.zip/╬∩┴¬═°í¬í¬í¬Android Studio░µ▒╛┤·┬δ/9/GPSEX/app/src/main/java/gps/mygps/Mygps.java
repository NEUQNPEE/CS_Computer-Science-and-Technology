package gps.mygps;

import gps.mygps.R;

import java.text.DateFormat;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.TimeZone;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.GpsSatellite;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Mygps extends Activity {
	
    protected static final String TAG = null;
  //λ����
	private Location location;
	// ��λ������
	private LocationManager locationManager;  
	private String provider;
	//�������Ǳ���
	private GpsStatus gpsStatus;
	Iterable<GpsSatellite> allSatellites;
	float satellitedegree[][] = new float[24][3];
	
	float alimuth[] = new  float[24];
	float elevation[] = new float[24]; 
	float snr[] = new float[24];
	
	private boolean status=false;
	protected Iterator<GpsSatellite> Iteratorsate;
	private float bear;
	
	//��ȡ�ֻ���Ļ�ֱ��ʵ���
	private DisplayMetrics dm;
	
	
	paintview layout;
	Button openbutton;
	Button closebutton;
	TextView latitudeview;
	TextView longitudeview;
	TextView altitudeview;
	TextView speedview;
	TextView timeview;
	TextView errorview;
	TextView bearingview;
	TextView satcountview;

	/** Called when the activity is first created. */
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
      requestWindowFeature(Window.FEATURE_NO_TITLE);
      getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
     
      setContentView(R.layout.main);
        
        findview();
        
        openbutton.setOnClickListener(new View.OnClickListener() {
    		
    		@Override
    		public void onClick(View v) {
    			// TODO Auto-generated method stub
    			if(!status)
    			 {
    				openGPSSettings();
    			     getLocation();
    			     status = true;
    			 }
    		}
    	});
        
        closebutton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				closeGps();
			}
		});
    }
    
    private void findview() {
		// TODO Auto-generated method stub
    	openbutton = (Button)findViewById(R.id.open);
    	closebutton = (Button)findViewById(R.id.close);
    	latitudeview = (TextView)findViewById(R.id.latitudevalue);
    	longitudeview = (TextView)findViewById(R.id.longitudevalue);
    	altitudeview = (TextView)findViewById(R.id.altitudevalue);
    	speedview = (TextView)findViewById(R.id.speedvalue);
    	timeview = (TextView)findViewById(R.id.timevalue);
    	errorview = (TextView)findViewById(R.id.error);
    	bearingview = (TextView)findViewById(R.id.bearvalue);
    	layout=(gps.mygps.paintview)findViewById(R.id.iddraw);
    	satcountview = (TextView)findViewById(R.id.satellitevalue);
	}


	protected void closeGps() {
		// TODO Auto-generated method stub
		
//   	 dm = new DisplayMetrics();
//		 getWindowManager().getDefaultDisplay().getMetrics(dm);
//		 heightp = dm.heightPixels;
//		 widthp = dm.widthPixels;
//		 alimuth[0] = 60;
//		elevation[0] = 20;
//		snr[0] = 60;
//		alimuth[1] = 260;
//		elevation[1] = 10;
//		snr[1] = 50;
//   	layout.redraw(240,alimuth,elevation,snr, widthp,heightp, 2);

		if(status == true)
		{
			locationManager.removeUpdates(locationListener);
			locationManager.removeGpsStatusListener(statusListener);
			errorview.setText("");  
			latitudeview.setText("");
    		longitudeview.setText("");
    		speedview.setText("");
    		timeview.setText("");
    		altitudeview.setText("");
    		bearingview.setText("");
    		satcountview.setText("");
			status = false;
		}
	}




	//��λ�����ฺ�����λ����Ϣ�ı仯���
    private final LocationListener locationListener = new LocationListener()
	{

		@Override
		public void onLocationChanged(Location location)
		{
		//	 ��ȡGPS��Ϣ   ��ȡλ���ṩ��provider�е�λ����Ϣ
//	    	location = locationManager.getLastKnownLocation(provider); 
	   // 	 ͨ��GPS��ȡλ��     
	    	updateToNewLocation(location);   
			//showInfo(getLastPosition(), 2);
		}

		@Override
		public void onProviderDisabled(String arg0)
		{
			
		}

		@Override
		public void onProviderEnabled(String arg0)
		{
		
		}

		@Override
		public void onStatusChanged(String arg0, int arg1, Bundle arg2)
		{
	    	updateToNewLocation(null);   
		}
	};
	

    //���Ӽ�������
    private final GpsStatus.Listener statusListener= new GpsStatus.Listener(){
		
		@Override
		public void onGpsStatusChanged(int event) {
			// TODO Auto-generated method stub
			//��ȡGPS������Ϣ
			gpsStatus = locationManager.getGpsStatus(null);
			
			switch(event)
			{
			case GpsStatus.GPS_EVENT_STARTED:
				
			break;
				//��һ�ζ�λʱ��
			case GpsStatus.GPS_EVENT_FIRST_FIX:
				
			break;
				//�յ���������Ϣ
			case GpsStatus.GPS_EVENT_SATELLITE_STATUS:
				DrawMap();
				
			break;
			
			case GpsStatus.GPS_EVENT_STOPPED:
			break;
			}
		}
	};
	private int heightp;
	private int widthp;
    
    private void openGPSSettings()
    {    	
    	
//    	 dm = new DisplayMetrics();
//		 getWindowManager().getDefaultDisplay().getMetrics(dm);
//		 heightp = dm.heightPixels;
//		 widthp = dm.widthPixels;
//    	alimuth[0] = 60;
//		elevation[0] = 70;
//		snr[0] = 60;
//		alimuth[1] = 260;
//		elevation[1] = 10;
//		snr[1] = 50;
//    	layout.redraw(50,alimuth,elevation,snr, widthp,heightp, 2);

    	// ��ȡλ�ù�������   
    	locationManager = (LocationManager)this.getSystemService(Context.LOCATION_SERVICE);        
    	if (locationManager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)) 
    	{         
    		Toast.makeText(this, "GPSģ������", Toast.LENGTH_SHORT).show();    
    		return;      
    	}    
    	status = false;
    	Toast.makeText(this, "�뿪��GPS��", Toast.LENGTH_SHORT).show();     
    	Intent intent = new Intent(Settings.ACTION_SECURITY_SETTINGS);     
    	startActivityForResult(intent,0); //��Ϊ������ɺ󷵻ص���ȡ����    }
    }
    

	protected void DrawMap() {
		// TODO Auto-generated method stub
		
		int i = 0;
		//��ȡ��Ļ��Ϣ
		 dm = new DisplayMetrics();
		 getWindowManager().getDefaultDisplay().getMetrics(dm);
		 heightp = dm.heightPixels;
		 widthp = dm.widthPixels;

		//��ȡ������Ϣ
		allSatellites = gpsStatus.getSatellites();
		Iteratorsate = allSatellites.iterator();
		
		while(Iteratorsate.hasNext())
		{
			GpsSatellite satellite = Iteratorsate.next();
			alimuth[i] = satellite.getAzimuth();
			elevation[i] = satellite.getElevation();
			snr[i] = satellite.getSnr();
			i++;
		}
		satcountview.setText(""+i);
    	layout.redraw(bear,alimuth,elevation,snr, widthp,heightp, i);
       	layout.invalidate();
	}

	private void getLocation()    
    {    

    	// ���ҵ�������Ϣ    λ�����ݱ�׼��
    	Criteria criteria = new Criteria();    
    	//��ѯ����:��
    	criteria.setAccuracy(Criteria.ACCURACY_FINE); 
    	// �Ƿ��ѯ����:��
    	criteria.setAltitudeRequired(true);
    	//�Ƿ��ѯ��λ��:��
    	criteria.setBearingRequired(true);
    	//�Ƿ���������
    	criteria.setCostAllowed(true);    
    	// ����Ҫ��:�� 
    	criteria.setPowerRequirement(Criteria.POWER_LOW);
    	//�Ƿ��ѯ�ٶ�:��
    	criteria.setSpeedRequired(true);
    	
    	provider = locationManager.getBestProvider(criteria, true);
    	
    	
    	// ��ȡGPS��Ϣ   ��ȡλ���ṩ��provider�е�λ����Ϣ
    	location = locationManager.getLastKnownLocation(provider); 
//    	// ͨ��GPS��ȡλ��     
    	updateToNewLocation(location);   
    	// ���ü��������Զ����µ���Сʱ��Ϊ���N��(1��Ϊ1*1000������д��ҪΪ�˷���)����Сλ�Ʊ仯����N��    
    	//ʵʱ��ȡλ���ṩ��provider�е����ݣ�һ������λ�ñ仯 ����֪ͨӦ�ó���
    	locationManager.requestLocationUpdates(provider, 1000, 0,locationListener);
    	//��������
    	locationManager.addGpsStatusListener(statusListener);
    	}
    
	
    private void updateToNewLocation(Location location) 
    {       

    	if (location != null)
    	{           
    		bear = location.getBearing();
    		double  latitude = location.getLatitude();      //ά��
    		double longitude= location.getLongitude();     //���� 
    		float GpsSpeed = location.getSpeed();	//�ٶ�	
    		long GpsTime = location.getTime();	//ʱ��
    		Date date = new Date(GpsTime);
    		
    		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    		
    		double GpsAlt = location.getAltitude();		//����
    		latitudeview.setText("" + latitude);
    		longitudeview.setText("" + longitude);
    		speedview.setText(""+GpsSpeed);
    		timeview.setText(""+df.format(date));
    		altitudeview.setText(""+GpsAlt);
    		bearingview.setText(""+bear);
  
    		} 
    	else
    	{     
    		errorview.setText("�޷���ȡ������Ϣ");  
    		}  
    	}

}