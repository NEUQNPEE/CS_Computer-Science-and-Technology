package gps.mygps;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;

public class paintview extends View{

	private Paint paint;
	private float direction;
	private float fwidth;
	private float fheight;
	private float dx;
	private float dy;
	private float startsnx;
	private float startsny;
	private float stopsnx;
	private float stopsny;
	private float startewx;
	private float startewy;
	private float stopewx;
	private float stopewy;
	private int flags;
	private float cx;
	private float cy;
	private float radius1;
	private float radius2;
	private float radius3;
	private float radius;
	private int cnt;
	private float angle;
	private float satradius;
	float satellite[][] = new float[24][3];

//	int icolor;
	
	public paintview(Context context,AttributeSet attrs)
	{
		super(context,attrs);
	}
	
	public void redraw(float bearing,float alimuth[],float elevation[], float snr[],float width,float height,int n) 
	{
		// TODO Auto-generated method stub
		this.direction = bearing;
		this.fheight= height;
		this.fwidth = width;
		this.cnt = n;
			for(int i = 0; i<n; i++)
			{
				satellite[i][0] = alimuth[i];
				satellite[i][1] = elevation[i];
				satellite[i][2] = snr[i];
			}
	}

	@Override
	protected void onDraw(Canvas canvas)
	{
		super.onDraw(canvas);
		
		//
		
//		canvas.drawColor(Color.BLUE);
		paint = new Paint();
		


		paint.setColor(Color.RED);
		paint.setStyle(Style.STROKE);
		paint.setStrokeWidth(1);
		paint.setAntiAlias(true);
		paint.setAlpha(0x80);
		canvas.drawCircle(fwidth/2,fheight/4, fwidth/8, paint);
		canvas.drawCircle(fwidth/2,fheight/4, fwidth/4, paint);
		canvas.drawCircle(fwidth/2,fheight/4, fwidth/8*3, paint);
		
		canvas.drawCircle(fwidth/2, fheight/4-fwidth/8*3, 2, paint);
//		canvas.drawLine((float)fwidth/2,(float)fheight/4, (float)fwidth/2,5, paint);
		
		canvas.drawLine((float)(fwidth/2-fwidth/8*3*Math.sin(direction*Math.PI/180)),(float)(fheight/4-fwidth/8*3*Math.cos(direction*Math.PI/180)),
				(float)(fwidth/2-fwidth/8*3*Math.sin((direction+180)*Math.PI/180)),(float)(fheight/4-fwidth/8*3*Math.cos((direction+180)*Math.PI/180)),paint);
		
		canvas.drawLine((float)(fwidth/2-fwidth/8*3*Math.sin((direction+90)*Math.PI/180)),(float)(fheight/4-fwidth/8*3*Math.cos((direction+90)*Math.PI/180)),
				(float)(fwidth/2-fwidth/8*3*Math.sin((direction+270)*Math.PI/180)),(float)(fheight/4-fwidth/8*3*Math.cos((direction+270)*Math.PI/180)),paint);
		
		
		for(int i = 0; i< cnt; i++)
		{
			radius = (float)(fwidth/8*3*Math.cos(satellite[i][1]*Math.PI/180));
			angle = satellite[i][0] - direction;
			cx = (float)(fwidth/2 - radius*Math.sin(angle*Math.PI/180));
			cy = (float)(fheight/4 - radius*Math.cos(angle)*Math.PI/180);
			satradius = satellite[i][2]/30;
			canvas.drawCircle(cx, cy, satradius, paint);
		}
		
		
	};
	
}