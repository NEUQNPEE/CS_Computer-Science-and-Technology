#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>
#include "PCB.h"
using namespace std;

int main(){
    ifstream fin("input.txt");
    if(!fin.is_open()){
        cout<<"file open ERROR!";
        return 0;
    }
    vector<PCB> pcb;

    string line;
    while(getline(fin, line)){
        vector<int> temp;
        stringstream ss(line);
        int x;
        while(ss >> x){
            temp.push_back(x);
        }
        if(temp.size() != 6){
            cout<<"fin ERROR!";
            return 0;
        }
        PCB pcb_temp = PCB(temp);
        pcb.push_back(pcb_temp);
    }
    fin.close();

    vector<int> ans;
    int flag = 1;
    int max_pr = pcb[0].priority;
    while(!pcb.empty()){
        //int len = pcb.size();
        for(vector<PCB>::iterator i = pcb.begin(); i != pcb.end();i++){
            if(i->priority > max_pr && i->startBlock != 0){
                flag = i->ID;
                max_pr = i->priority;
                continue;
            }
            if(i->priority == max_pr && i->ID < flag && i->startBlock != 0){
                flag = i->ID;
                max_pr = i->priority;
            }
        }
        for(vector<PCB>::iterator i = pcb.begin(); i != pcb.end();i++){
            if(i->ID != flag){
                if(i->startBlock == 0){
                    if(i->blockTime > 0)i->blockTime--;
                    if(i->blockTime == 0)i->startBlock = -1;
                }
                else i->priority++;
            }
            else{
                i->priority -= 3;
                max_pr -= 3;
                i->startBlock--;
                i->allTime--;
                if(i->allTime == 0){
                    ans.push_back(i->ID);
                    pcb.erase(i);
                    max_pr = 0;
                    flag = 100;
                    break;
                }
            }
        }
    }

    
    int len = ans.size();
    for(int i = 0; i < len; i++){
        cout<<ans[i];
        if(i != len - 1)cout<<' ';
    }
    return 0;

}