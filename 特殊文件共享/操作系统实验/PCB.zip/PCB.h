#include <vector>
#include <iostream>
using namespace std;

class PCB{
    public:
        int ID;
        int priority;
        int CPUtime;
        int allTime;
        int startBlock;
        int blockTime;
        bool state = true;

        PCB(){}

        PCB(vector<int>& var){
            if(var.size() < 6){
                cout<<"fin ERROR!";
                exit(0);
            }
            ID = var[0];
            priority = var[1];
            CPUtime = var[2];
            allTime = var[3];
            startBlock = var[4];
            blockTime = var[5];
        }

};